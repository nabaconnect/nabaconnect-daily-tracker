NABACONNECT DAILY TRACKER — ANDROID SOURCE PROJECT

Muhimmin bayani:
- Wannan SOURCE PROJECT ne na Android Studio, ba APK da aka riga aka compile ba.
- An tsara app ɗin ya yi aiki offline, ba tare da tallace-tallace ko permission na internet ba.
- Bayanai suna cikin ajiyar app ɗin a wayar. Kada a uninstall app ko clear data ba tare da backup ba.
- App ɗin yana amfani da HTML/JavaScript da aka haɗa a cikin app, saboda haka ba ya buƙatar internet domin buɗewa.

Yadda za a gina APK:
1. Buɗe wannan project a Android Studio a kwamfuta.
2. Jira Gradle Sync ya gama.
3. Zaɓi Build > Build APK(s).
4. APK ɗin debug zai kasance a app/build/outputs/apk/debug/app-debug.apk.

Idan kana amfani da waya kawai:
- Za ka buƙaci Android IDE mai iya buɗe Android Gradle project da SDK; ba duk apps na coding ke iya compile APK ba.
- Kada ka ɗora source code ko bayanan sirri a shafin da ba ka amince da shi ba.

Application ID: com.nabaconnect.dailytracker
Version: 1.0
